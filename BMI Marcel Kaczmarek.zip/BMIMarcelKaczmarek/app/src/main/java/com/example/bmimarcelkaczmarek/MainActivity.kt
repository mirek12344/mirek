package com.example.bmimarcelkaczmarek

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var genderGroup: RadioGroup
    private lateinit var ageEditText: EditText
    private lateinit var weightEditText: EditText
    private lateinit var heightEditText: EditText
    private lateinit var activityLevelGroup: RadioGroup
    private lateinit var calculateButton: Button
    private lateinit var historyButton: Button
    private lateinit var resultTextView: TextView
    private lateinit var historyListView: ListView

    private val historyList = mutableListOf<String>()
    private lateinit var historyAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        genderGroup = findViewById(R.id.genderGroup)
        ageEditText = findViewById(R.id.age)
        weightEditText = findViewById(R.id.weight)
        heightEditText = findViewById(R.id.height)
        activityLevelGroup = findViewById(R.id.activityLevelGroup)
        calculateButton = findViewById(R.id.calculateButton)
        historyButton = findViewById(R.id.historyButton)
        resultTextView = findViewById(R.id.resultTextView)
        historyListView = findViewById(R.id.historyListView)

        historyAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, historyList)
        historyListView.adapter = historyAdapter

        calculateButton.setOnClickListener {
            calculateResults()
        }

        historyButton.setOnClickListener {
            toggleHistory()
        }
    }

    private fun calculateResults() {
        val genderId = genderGroup.checkedRadioButtonId
        val age = ageEditText.text.toString().toIntOrNull() ?: return
        val weight = weightEditText.text.toString().toDoubleOrNull() ?: return
        val height = heightEditText.text.toString().toIntOrNull() ?: return
        val activityLevelId = activityLevelGroup.checkedRadioButtonId

        val genderFactor = if (genderId == R.id.male) 5 else -161
        val activityFactor = when (activityLevelId) {
            R.id.activityLevel0 -> if (genderId == R.id.male) 1.2 else 1.2
            R.id.activityLevel1 -> if (genderId == R.id.male) 1.3 else 1.3
            R.id.activityLevel2 -> if (genderId == R.id.male) 1.6 else 1.5
            R.id.activityLevel3 -> if (genderId == R.id.male) 1.7 else 1.6
            R.id.activityLevel4 -> if (genderId == R.id.male) 2.1 else 1.9
            R.id.activityLevel5 -> if (genderId == R.id.male) 2.4 else 2.2
            else -> return
        }

        val bmi = weight / ((height / 100.0) * (height / 100.0))
        val ppm = (10 * weight) + (6.25 * height) - (5 * age) + genderFactor
        val cpm = ppm * activityFactor

        val result = String.format("BMI: %.2f\nPPM: %.2f\nCPM: %.2f", bmi, ppm, cpm)
        resultTextView.text = result

        // Save result to history
        val historyEntry = String.format("Wiek: %d, Waga: %.2f kg, Wzrost: %d cm\nBMI: %.2f, PPM: %.2f, CPM: %.2f",
            age, weight, height, bmi, ppm, cpm)
        historyList.add(historyEntry)
        historyAdapter.notifyDataSetChanged()
    }

    private fun toggleHistory() {
        if (historyListView.visibility == ListView.GONE) {
            historyListView.visibility = ListView.VISIBLE
        } else {
            historyListView.visibility = ListView.GONE
        }
    }
}